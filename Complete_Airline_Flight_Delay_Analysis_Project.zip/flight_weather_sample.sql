CREATE TABLE flight_weather (
    year INT,
    month INT,
    day INT,
    DayOfWeek VARCHAR(15),
    carrier VARCHAR(10),
    name VARCHAR(50),
    origin VARCHAR(10),
    dest VARCHAR(10),
    dep_delay FLOAT,
    arr_delay FLOAT,
    TotalDelay FLOAT,
    on_time BOOLEAN,
    route VARCHAR(20),
    date DATE,
    temperature FLOAT,
    wind_speed FLOAT,
    precipitation BOOLEAN,
    visibility FLOAT,
    weather_condition VARCHAR(20)
);

INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'IAH', 2.0, 11.0, 13.0, False, 'EWR → IAH', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'LGA', 'IAH', 4.0, 20.0, 24.0, False, 'LGA → IAH', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'JFK', 'MIA', 2.0, 33.0, 35.0, False, 'JFK → MIA', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'BQN', -1.0, -18.0, -19.0, True, 'JFK → BQN', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'DL', 'Delta Air Lines Inc.', 'LGA', 'ATL', -6.0, -25.0, -31.0, True, 'LGA → ATL', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'ORD', -4.0, 12.0, 8.0, False, 'EWR → ORD', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'EWR', 'FLL', -5.0, 19.0, 14.0, False, 'EWR → FLL', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'EV', 'ExpressJet Airlines Inc.', 'LGA', 'IAD', -3.0, -14.0, -17.0, True, 'LGA → IAD', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'MCO', -3.0, -8.0, -11.0, True, 'JFK → MCO', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'LGA', 'ORD', -2.0, 8.0, 6.0, False, 'LGA → ORD', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'PBI', -2.0, -2.0, -4.0, True, 'JFK → PBI', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'TPA', -2.0, -3.0, -5.0, True, 'JFK → TPA', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'JFK', 'LAX', -2.0, 7.0, 5.0, False, 'JFK → LAX', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'SFO', -2.0, -14.0, -16.0, True, 'EWR → SFO', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'LGA', 'DFW', -1.0, 31.0, 30.0, False, 'LGA → DFW', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'BOS', 0.0, -4.0, -4.0, True, 'JFK → BOS', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'LAS', -1.0, -8.0, -9.0, True, 'EWR → LAS', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'LGA', 'FLL', 0.0, -7.0, -7.0, True, 'LGA → FLL', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'MQ', 'Envoy Air', 'LGA', 'ATL', 0.0, 12.0, 12.0, False, 'LGA → ATL', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'EWR', 'PBI', 1.0, -6.0, -5.0, True, 'EWR → PBI', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'DL', 'Delta Air Lines Inc.', 'LGA', 'MSP', -8.0, -8.0, -16.0, True, 'LGA → MSP', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'MQ', 'Envoy Air', 'LGA', 'DTW', -3.0, 16.0, 13.0, False, 'LGA → DTW', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'EWR', 'MIA', -4.0, -12.0, -16.0, True, 'EWR → MIA', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'DL', 'Delta Air Lines Inc.', 'JFK', 'ATL', -4.0, -8.0, -12.0, True, 'JFK → ATL', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'MIA', 0.0, -17.0, -17.0, True, 'EWR → MIA', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'MQ', 'Envoy Air', 'EWR', 'ORD', 8.0, 32.0, 40.0, False, 'EWR → ORD', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'JFK', 'SFO', 11.0, 14.0, 25.0, False, 'JFK → SFO', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'RSW', 3.0, 4.0, 7.0, False, 'JFK → RSW', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'SJU', 0.0, -21.0, -21.0, True, 'JFK → SJU', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'DL', 'Delta Air Lines Inc.', 'EWR', 'ATL', 0.0, -9.0, -9.0, True, 'EWR → ATL', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'US', 'US Airways Inc.', 'EWR', 'PHX', -8.0, 3.0, -5.0, False, 'EWR → PHX', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'LGA', 'MIA', 13.0, 5.0, 18.0, False, 'LGA → MIA', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'LGA', 'IAH', -4.0, 1.0, -3.0, False, 'LGA → IAH', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'EV', 'ExpressJet Airlines Inc.', 'EWR', 'MSP', -6.0, 29.0, 23.0, False, 'EWR → MSP', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'MQ', 'Envoy Air', 'LGA', 'MSP', -6.0, 10.0, 4.0, False, 'LGA → MSP', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'US', 'US Airways Inc.', 'JFK', 'PHX', -3.0, 0.0, -3.0, True, 'JFK → PHX', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'JFK', 'SJU', -2.0, -3.0, -5.0, True, 'JFK → SJU', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'LAX', -2.0, 29.0, 27.0, False, 'EWR → LAX', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'LGA', 'ORD', -1.0, 14.0, 13.0, False, 'LGA → ORD', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'WN', 'Southwest Airlines Co.', 'LGA', 'BWI', -1.0, -19.0, -20.0, True, 'LGA → BWI', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'US', 'US Airways Inc.', 'EWR', 'CLT', -1.0, -9.0, -10.0, True, 'EWR → CLT', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'EV', 'ExpressJet Airlines Inc.', 'EWR', 'IAD', 24.0, 12.0, 36.0, False, 'EWR → IAD', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'LGA', 'DFW', 0.0, 48.0, 48.0, False, 'LGA → DFW', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'LGA', 'MCO', -8.0, -5.0, -13.0, True, 'LGA → MCO', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'BOS', -1.0, -10.0, -11.0, True, 'JFK → BOS', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'PBI', -3.0, -18.0, -21.0, True, 'EWR → PBI', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'US', 'US Airways Inc.', 'EWR', 'CLT', -2.0, -11.0, -13.0, True, 'EWR → CLT', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'FLL', 8.0, -9.0, -1.0, True, 'EWR → FLL', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'BUF', -2.0, 5.0, 3.0, False, 'JFK → BUF', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'LGA', 'DEN', 1.0, -6.0, -5.0, True, 'LGA → DEN', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'SNA', 1.0, -7.0, -6.0, True, 'EWR → SNA', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'LAS', -4.0, -6.0, -10.0, True, 'JFK → LAS', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'MSY', -3.0, 11.0, 8.0, False, 'JFK → MSY', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'DL', 'Delta Air Lines Inc.', 'LGA', 'PBI', -7.0, -33.0, -40.0, True, 'LGA → PBI', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'DL', 'Delta Air Lines Inc.', 'JFK', 'SLC', 0.0, -9.0, -9.0, True, 'JFK → SLC', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'DL', 'Delta Air Lines Inc.', 'JFK', 'SFO', -5.0, -8.0, -13.0, True, 'JFK → SFO', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'DL', 'Delta Air Lines Inc.', 'LGA', 'MIA', -5.0, -18.0, -23.0, True, 'LGA → MIA', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'LGA', 'ORD', -4.0, 4.0, 0.0, False, 'LGA → ORD', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'JFK', 'MCO', -3.0, -10.0, -13.0, True, 'JFK → MCO', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'MQ', 'Envoy Air', 'LGA', 'XNA', -9.0, 27.0, 18.0, False, 'LGA → XNA', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'TPA', -4.0, -23.0, -27.0, True, 'EWR → TPA', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'DL', 'Delta Air Lines Inc.', 'LGA', 'FLL', -3.0, -14.0, -17.0, True, 'LGA → FLL', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'DL', 'Delta Air Lines Inc.', 'LGA', 'ATL', -2.0, 5.0, 3.0, False, 'LGA → ATL', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'VX', 'Virgin America', 'JFK', 'LAX', -2.0, 2.0, 0.0, False, 'JFK → LAX', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'LGA', 'MIA', -1.0, -7.0, -8.0, True, 'LGA → MIA', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'FLL', -1.0, 1.0, 0.0, False, 'JFK → FLL', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'DL', 'Delta Air Lines Inc.', 'LGA', 'DTW', -6.0, -6.0, -12.0, True, 'LGA → DTW', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'RSW', -1.0, -9.0, -10.0, True, 'EWR → RSW', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'SJU', 1.0, -31.0, -30.0, True, 'EWR → SJU', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'LAX', 2.0, 44.0, 46.0, False, 'JFK → LAX', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'LGA', 'ORD', 9.0, 20.0, 29.0, False, 'LGA → ORD', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'SJU', -4.0, -15.0, -19.0, True, 'JFK → SJU', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'JFK', 'FLL', -3.0, -12.0, -15.0, True, 'JFK → FLL', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'ORD', 2.0, 21.0, 23.0, False, 'EWR → ORD', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'FL', 'AirTran Airways Corporation', 'LGA', 'MKE', -3.0, 10.0, 7.0, False, 'LGA → MKE', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'MCO', -2.0, 5.0, 3.0, False, 'JFK → MCO', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'PBI', -2.0, -4.0, -6.0, True, 'EWR → PBI', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'LGA', 'DFW', -6.0, 31.0, 25.0, False, 'LGA → DFW', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AS', 'Alaska Airlines Inc.', 'EWR', 'SEA', -1.0, -10.0, -11.0, True, 'EWR → SEA', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'EWR', 'DFW', -5.0, 12.0, 7.0, False, 'EWR → DFW', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'DEN', -3.0, 7.0, 4.0, False, 'EWR → DEN', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'LGA', 'IAH', -4.0, 3.0, -1.0, False, 'LGA → IAH', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'VX', 'Virgin America', 'JFK', 'SFO', -1.0, -26.0, -27.0, True, 'JFK → SFO', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'ROC', -3.0, -1.0, -4.0, True, 'JFK → ROC', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'LGA', 'RSW', 3.0, 2.0, 5.0, False, 'LGA → RSW', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'MCO', 47.0, 30.0, 77.0, False, 'EWR → MCO', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'SYR', -3.0, 4.0, 1.0, False, 'JFK → SYR', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'SFO', -3.0, -26.0, -29.0, True, 'JFK → SFO', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'LGA', 'ORD', -6.0, -12.0, -18.0, True, 'LGA → ORD', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'IAH', 0.0, 26.0, 26.0, False, 'EWR → IAH', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'LGA', 'TPA', -4.0, 2.0, -2.0, False, 'LGA → TPA', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'JFK', 'LAX', 13.0, 7.0, 20.0, False, 'JFK → LAX', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'B6', 'JetBlue Airways', 'JFK', 'SRQ', -6.0, -11.0, -17.0, True, 'JFK → SRQ', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'DL', 'Delta Air Lines Inc.', 'JFK', 'SEA', 13.0, 3.0, 16.0, False, 'JFK → SEA', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'AA', 'American Airlines Inc.', 'JFK', 'SFO', 0.0, 10.0, 10.0, False, 'JFK → SFO', '2013-01-01', 23.23844269050346, 11.94314190190871, 1, 8.824416307710642, 'Rain');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'EWR', 'SFO', 0.0, -10.0, -10.0, True, 'EWR → SFO', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'MQ', 'Envoy Air', 'EWR', 'ORD', 39.0, 49.0, 88.0, False, 'EWR → ORD', '2013-01-01', 22.483570765056164, 13.510681684886409, 0, 7.668012733634392, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'DL', 'Delta Air Lines Inc.', 'LGA', 'MCO', -3.0, -18.0, -21.0, True, 'LGA → MCO', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'UA', 'United Air Lines Inc.', 'LGA', 'DEN', 2.0, -4.0, -2.0, True, 'LGA → DEN', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
INSERT INTO flight_weather VALUES (2013.0, 1.0, 1.0, 'Tuesday', 'US', 'US Airways Inc.', 'LGA', 'CLT', -7.0, -4.0, -11.0, True, 'LGA → CLT', '2013-01-01', 19.308678494144075, 9.502071703041851, 0, 8.039525463967223, 'Clear');
